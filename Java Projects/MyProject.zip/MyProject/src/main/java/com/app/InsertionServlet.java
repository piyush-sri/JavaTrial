package com.app;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.swing.JOptionPane;


@MultipartConfig(maxFileSize = 10000000L)
public class InsertionServlet  extends HttpServlet{
	
	Connection cn;
	
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
		
		try {
				cn=(Connection)config.getServletContext().getAttribute("CONN");
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
			
			JOptionPane.showMessageDialog(null, "Reason of Error::"+e.getMessage());
		}
	}
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String name=req.getParameter("txt_ename");
		double salary=Double.parseDouble(req.getParameter("txt_esalary"));
		
		
		
		
		PrintWriter out=resp.getWriter();
		resp.setContentType("text/html");
		try {
			
			Part _image_in_part=req.getPart("file_upload");
			
			InputStream ins=_image_in_part.getInputStream();
			
			PreparedStatement ps=cn.prepareStatement("insert into employee(name,salary,image) values(?,?,?)");
			ps.setString(1, name);
			ps.setDouble(2, salary);
			ps.setBlob(3, ins);
			
			int a=ps.executeUpdate();
			if(a>0)
				{
						RequestDispatcher rd=req.getRequestDispatcher("/InsertEmployee.jsp");
						rd.include(req, resp);
						out.println("<hr>");
						out.println("<div align=center>");
						out.println("Record Has Been Inserted!");
						
						out.println("</div>");
				
				}
			
		} catch (Exception e) {
			// TODO: handle exception
			
			JOptionPane.showMessageDialog(null, "Reason of Error::"+e.getMessage());
		}
		
		
		out.close();
	}

}
