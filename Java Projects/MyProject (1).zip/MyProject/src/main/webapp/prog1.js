/**
 * 
 */

 

 
 
 function makeRequestObject()
 	{
		 
		 var xmlHttp=false;
		 
		 try
		 	{
				 
				 xmlHttp=new ActiveXObject('Msxml2.XMLHTTP');
			 }
		catch(e)
			{
				try
					{
						xmlHttp=new ActiveXObject('Microsoft.XMLHTTP');
						
					}
				catch(E)
					{
						
						xmlHttp=false;
					}
				
			}
			
			
		if(!xmlHttp && typeof(XMLHttpRequest)!='undefined')
			{
				
					xmlHttp=new XMLHttpRequest();
			}
		 
		 return xmlHttp;
	 }
	 
	 
	 function sendData(val)
	 	{
			 var xmlHttp=makeRequestObject();
			 var _url='SearchByName.jsp?ename='+val;
			 
			 xmlHttp.open('GET',_url,true);
			 
			 xmlHttp.onreadystatechange=function()
			 									{
													if(xmlHttp.readyState==4 && xmlHttp.status==200)
														{
															
															var content=xmlHttp.responseText;
															
															if(content)
																{
																	
																	document.getElementById("info").innerHTML=content;
																}
														} 
													 
													 
												 };
			 
			 
			 
			 xmlHttp.send(null);
			 
		}