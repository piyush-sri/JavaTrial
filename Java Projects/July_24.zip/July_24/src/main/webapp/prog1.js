/**
 * 
 */

 
function makeRequestObject()	
	{
		var xmlHttp=false;
		try
			{
				
				xmlHttp=new ActiveXObject('Msxml2.XMLHTTP');
			}
		catch(e)
			{
				try
					{
						
							xmlHttp=new ActiveXObject('Microsoft.XMLHTTP');
					}
				catch(E)
					{
						
						xmlHttp=false;
					}
				
				
			}
			
			
		if(!xmlHttp && typeof(XMLHttpRequest)!='undefined')
			{
				
				
				xmlHttp=new XMLHttpRequest();
			}
		
		return xmlHttp;
		
	}
	
	
	
	function sendDataAndReturnOutput(val)
		{
			var xmlHttp=makeRequestObject();
			
			var _url='output.jsp?value='+val;
			
			
			
			xmlHttp.open('GET',_url,true);  //For Asynchronous Request Sending
			
			xmlHttp.onreadystatechange=function()
											{
												
												if(xmlHttp.readyState==4 && xmlHttp.status==200)
													{
														var content=xmlHttp.responseText;
														
														if(content)
														{
															
															
															document.getElementById("info").innerHTML=content;
														}
														
													}
												
												
											}
			
			
			xmlHttp.send(null);
			
		}
		
		
		
function populateCities(val)
		{
			var xmlHttp=makeRequestObject();
			
			var _url='showRelevantCities.jsp?sname='+val;
			
			
			
			xmlHttp.open('GET',_url,true);  //For Asynchronous Request Sending
			
			xmlHttp.onreadystatechange=function()
											{
												
												if(xmlHttp.readyState==4 && xmlHttp.status==200)
													{
														var content=xmlHttp.responseText;
														
														if(content)
														{
															
															
															document.getElementById("info").innerHTML=content;
														}
														
													}
												
												
											}
			
			
			xmlHttp.send(null);
			
		}
		
		
		
		
		
		
		
		